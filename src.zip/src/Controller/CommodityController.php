<?php
namespace Drupal\unee_trifedapi\Controller;
use Drupal\Core\Controller\ControllerBase;

class CommodityController extends ControllerBase{	
	public function content(){
		  $client = \Drupal::httpClient();		  
		  $request = $client->get(TRIFED_API_URL);		  
		  $response = json_decode($request->getBody());
		  $rend_arr = $response->data;		  
		  //print_r($rend_arr);exit;
		return array(
	      '#theme' => 'unee_trifedapi_template',
	      '#trifed_var' => $rend_arr,
	    );
	}	
	public function snd(){
		  $client = \Drupal::httpClient();
		  $request = $client->get(TRIFED_SNDSIO_URL);		  
		  $response = json_decode($request->getBody());
		  $snd_arr = $response->data->snd;		  
		  //print_r($snd_arr);exit;
		return array(
	      '#theme' => 'unee_snd_template',
	      '#snd_var' => $snd_arr,
	    );
	}	
	public function sio(){
		  $client = \Drupal::httpClient();		 
		  $request = $client->get(TRIFED_SNDSIO_URL);		  
		  $response = json_decode($request->getBody());
		  //echo '<pre>';print_r($response);exit;
		  $snd_arr = $response->data->snd;		  
		  $sio_arr = $response->data->sio;		  
		  $data=array();
		  if(!empty($snd_arr))
		  {
			  foreach($snd_arr as $row)
			  {
				  $data[$row->state]['snd'][]=$row;
			  }
		  }
		  if(!empty($sio_arr))
		  {
			  foreach($sio_arr as $row)
			  {
				  $data[$row->state]['sio'][]=$row;
			  }
		  }
		 //echo '<pre>';print_r($data); exit;
		return array(
	      '#theme' => 'unee_sio_template',
	      '#sio_var' => $data,
	    );
	}		
}